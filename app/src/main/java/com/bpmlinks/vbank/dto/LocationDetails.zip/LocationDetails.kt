package com.bpmlinks.vbank.dto

data class LocationDetails (val longitutde:String,val latitude:String){
}